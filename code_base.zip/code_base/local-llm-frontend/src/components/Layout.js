import React from 'react';
import TopNavBar from './TopNavBar';
import SideMenu from './SideMenu';
import Box from '@mui/material/Box';
import CssBaseline from '@mui/material/CssBaseline';

function Layout({ children }) {
    return (
        <Box sx={{ display: 'flex' }}>
            <CssBaseline />
            <TopNavBar />
            <Box sx={{ display: 'flex', mt: '40px' }}>
                <SideMenu />
                <Box component="main" sx={{ flexGrow: 1, p: 3, ml: '240px', mt: 0 }}>
                    {children}
                </Box>
            </Box>
        </Box>
    );
}

export default Layout;
