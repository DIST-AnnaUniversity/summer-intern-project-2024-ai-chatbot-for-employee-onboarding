import React from 'react';
import { Link } from 'react-router-dom';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import { Box, Typography } from '@mui/material';
import Logo from './cei-logo.png'; // Import your logo file

function SideMenu() {
    return (
        <Drawer
            variant="permanent"
            anchor="left"
            sx={{ top: '20px', height: 'calc(100% - 20px)', mt: '20px' }}
        >
            <Box sx={{ p: 2, textAlign: 'center' }}>
                <img src={Logo} alt="Logo" style={{ width: '50%', height: 'auto' }} />
                <Typography variant="body2" color="textSecondary" sx={{ mt: 2 }}>
                    &nbsp;
                </Typography>
                <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
                    &nbsp;
                </Typography>
            </Box>
            <List>
                <ListItem button component={Link} to="/">
                    <ListItemText primary="Upload" />
                </ListItem>
                <ListItem button component={Link} to="/listfiles">
                    <ListItemText primary="List Files" />
                </ListItem>
                <ListItem button component={Link} to="/chat">
                    <ListItemText primary="Chat" />
                </ListItem>
            </List>
        </Drawer>
    );
}

export default SideMenu;
