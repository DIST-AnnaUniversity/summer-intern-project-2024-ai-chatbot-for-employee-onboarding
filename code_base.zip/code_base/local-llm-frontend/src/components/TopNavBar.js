import React from 'react';
import { useNavigate } from 'react-router-dom';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';

function TopNavBar() {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem('auth');
        navigate('/login');
    };

    return (
        <AppBar position="fixed" sx={{ width: '100vw', height: '40px', justifyContent: 'space-between', padding: '1px', top: 0, left: 0 }}>
            <Toolbar sx={{ minHeight: '40px', padding: 0 }}>
                <Button color="inherit" onClick={handleLogout}>Logout</Button>
            </Toolbar>
        </AppBar>
    );
}

export default TopNavBar;
