import React, { useState } from 'react';
import axios from 'axios';
import './Upload.css'; // Make sure to create and import a CSS file for styling

function Upload() {
    const [employeeID, setEmployeeID] = useState('');
    const [employeeName, setEmployeeName] = useState('');
    const [documentName, setDocumentName] = useState('');
    const [file, setFile] = useState(null);

    const handleFileChange = (event) => {
        if (event.target.files[0] && event.target.files[0].type === 'application/pdf') {
            setFile(event.target.files[0]);
        } else {
            alert('Please upload a PDF file');
        }
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        if (!file) {
            alert('Please upload a file first');
            return;
        }

        const formData = new FormData();
        formData.append('employeeID', employeeID);
        formData.append('employeeName', employeeName);
        formData.append('documentName', documentName);
        formData.append('file', file);

        try {
            const response = await axios.post('http://localhost:4000/uploadfiles', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            alert('File uploaded successfully');
        } catch (error) {
            console.error('Error uploading file:', error);
            alert('Failed to upload file');
        }
    };

    return (
        <div className="upload-container">
            <h1>Upload Document</h1>
            <form onSubmit={handleSubmit} className="upload-form">
                <div className="form-group">
                    <label htmlFor="employeeID">Employee ID:</label>
                    <input
                        id="employeeID"
                        type="text"
                        value={employeeID}
                        onChange={(e) => setEmployeeID(e.target.value)}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="employeeName">Employee Name:</label>
                    <input
                        id="employeeName"
                        type="text"
                        value={employeeName}
                        onChange={(e) => setEmployeeName(e.target.value)}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="documentName">Document Name:</label>
                    <input
                        id="documentName"
                        type="text"
                        value={documentName}
                        onChange={(e) => setDocumentName(e.target.value)}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="fileUpload">Upload PDF:</label>
                    <input id="fileUpload" type="file" onChange={handleFileChange} />
                </div>
                <button type="submit" className="submit-button">Save</button>
            </form>
        </div>
    );
}

export default Upload;
