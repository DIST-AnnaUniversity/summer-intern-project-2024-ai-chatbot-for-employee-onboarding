import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { FaTrash } from 'react-icons/fa';

function Employees() {
    const [employees, setEmployees] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:4000/list_employees')
            .then(response => {
                setEmployees(response.data);
            })
            .catch(error => {
                console.error('Error fetching employees:', error);
            });
    }, []);

    const handleDelete = (employeeID, fileName) => {
        axios.post('http://localhost:4000/delete_document', { employeeID, fileName })
            .then(response => {
                if (response.status === 200) {
                    setEmployees(employees.filter(employee => employee.fileName !== fileName));
                }
            })
            .catch(error => {
                console.error('Error deleting document:', error);
            });
    };

    return (
        <div style={{ marginLeft: '200px', padding: '20px', fontFamily: 'Arial, sans-serif' }}>
            <h1 style={{ textAlign: 'center' }}>Employees List</h1>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                <tr>
                    <th colSpan="4" style={{ textAlign: 'left', borderBottom: '2px solid #ddd', padding: '10px 0' }}>Employee Information</th>
                    <th style={{ textAlign: 'left', borderBottom: '2px solid #ddd', padding: '10px 0' }}>Actions</th>
                </tr>
                <tr>
                    <th style={{ textAlign: 'left', borderBottom: '2px solid #ddd', padding: '10px' }}>Employee ID</th>
                    <th style={{ textAlign: 'left', borderBottom: '2px solid #ddd', padding: '10px' }}>Employee Name</th>
                    <th style={{ textAlign: 'left', borderBottom: '2px solid #ddd', padding: '10px' }}>Document Name</th>
                    <th style={{ textAlign: 'left', borderBottom: '2px solid #ddd', padding: '10px' }}>File Name</th>
                    <th style={{ textAlign: 'left', borderBottom: '2px solid #ddd', padding: '10px' }}>Delete</th>
                </tr>
                </thead>
                <tbody>
                {employees.map(employee => (
                    <tr key={employee.fileName}>
                        <td style={{ padding: '10px', borderBottom: '1px solid #ddd' }}>{employee.employeeId}</td>
                        <td style={{ padding: '10px', borderBottom: '1px solid #ddd' }}>{employee.employeeName}</td>
                        <td style={{ padding: '10px', borderBottom: '1px solid #ddd' }}>{employee.documentName}</td>
                        <td style={{ padding: '10px', borderBottom: '1px solid #ddd' }}>{employee.fileName}</td>
                        <td style={{ padding: '10px', borderBottom: '1px solid #ddd', textAlign: 'center' }}>
                            <FaTrash
                                style={{ cursor: 'pointer', color: 'red' }}
                                onClick={() => handleDelete(employee.employeeID, employee.fileName)}
                            />
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
    );
}

export default Employees;
