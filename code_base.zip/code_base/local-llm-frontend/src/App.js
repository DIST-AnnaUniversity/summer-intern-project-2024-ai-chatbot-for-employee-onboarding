// src/App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Upload from './pages/Upload';
import ListFiles from './pages/ListFiles';
import Chat from './pages/Chat';
import Login from './pages/Login';
import Layout from './components/Layout';

function App() {
    const [authenticated, setAuthenticated] = useState(false);

    return (
        <Router>
            <Routes>
                <Route path="/login" element={<Login setAuthenticated={setAuthenticated} />} />
                <Route path="/" element={
                    authenticated ? (
                        <Layout>
                            <Upload />
                        </Layout>
                    ) : (
                        <Navigate to="/login" />
                    )
                } />
                <Route path="/listfiles" element={
                    authenticated ? (
                        <Layout>
                            <ListFiles />
                        </Layout>
                    ) : (
                        <Navigate to="/login" />
                    )
                } />
                <Route path="/chat" element={
                    authenticated ? (
                        <Layout>
                            <Chat />
                        </Layout>
                    ) : (
                        <Navigate to="/login" />
                    )
                } />
            </Routes>
        </Router>
    );
}

export default App;
