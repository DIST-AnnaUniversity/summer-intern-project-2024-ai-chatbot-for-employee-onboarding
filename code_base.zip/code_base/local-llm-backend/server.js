const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const cors = require('cors');
const axios = require('axios');
const mongoose = require("mongoose");
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const app = express();
const PORT = 4000;

app.use(cors());
app.use(bodyParser.json());


mongoose.connect('mongodb://localhost:27017/employee_db', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err));

//Define a Mongoose schema and model
const transactionSchema = new mongoose.Schema({
    employeeId: String,
    employeeName: String,
    documentName: String,
    fileName: String
});

const Transaction = mongoose.model('employees', transactionSchema);

// Ensure the directory exists
const uploadDirectory = path.join(__dirname, 'rag_files');
if (!fs.existsSync(uploadDirectory)) {
    fs.mkdirSync(uploadDirectory, { recursive: true });
}

//File Upload functions
// Configure Multer to save files in the rag_files directory
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDirectory);
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});

const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype === 'application/pdf') {
            cb(null, true);
        } else {
            cb(new Error('Only PDF files are allowed!'), false);
        }
    }
});

async function send_file_for_loading(filename) {
    const filePath = path.join(__dirname, 'rag_files', filename);

    // Check if the file exists
    if (!fs.existsSync(filePath)) {
        return `Error: File ${filename} does not exist in rag_files folder.`;
    }

    try {
        const fileContent = fs.readFileSync(filePath, 'utf8');

        const response = await axios.post('http://localhost:8000/loadvectordb', {
            fileContent: fileContent
        });

        return response.data; // Assuming the response contains a success message
    } catch (error) {
        return `Error: ${error.message}`;
    }
}


// ALL APP ENDPOINTS

// Authentication to be implemented later
app.post('/authenticateUser', (req, res) => {
    const { email, password } = req.body;
    // Replace with your authentication logic
    if (email === 'user@example.com' && password === 'egpword#001') {
        res.json({ success: true });
    } else {
        res.json({ success: false });
    }
});

// Sample endpoint that only talks to ChatGPT
app.post('/callOpenAI', async (req, res) => {
    const { message } = req.body;
    const apiKey = process.env.OPENAI_API_KEY;
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/engines/gpt-3.5-turbo-instruct/completions',
            {
                prompt: message,
                max_tokens: 150,
                temperature: 0.7,
                top_p: 1,
                frequency_penalty: 0,
                presence_penalty: 0,
            },
            {
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        res.json({ response: response.data.choices[0].text });
    } catch (error) {
        console.error('Error calling OpenAI:', error.response ? error.response.data : error.message);
        res.status(500).send('Error calling OpenAI');
    }
});

// Endpoint for RAG integration with app
app.post('/bot_response', async (req, res) => {
    const { message } = req.body;
    try {
        const response = await axios.post(
            'http://localhost:8000/bot_response/',  // Ensure the FastAPI server is running on localhost:8000
            { message },
            {
                headers: {
                    'Content-Type': 'application/json',
                },
            }
        );

        res.json({ response: response.data.data });
    } catch (error) {
        console.error('Error calling FastAPI bot_response endpoint:', error.response ? error.response.data : error.message);
        res.status(500).send('Error calling bot_response endpoint');
    }
});

//File upload to MongoDB and then send to Pinecone
app.post('/uploadfiles', upload.single('file'), async (req, res) => {
    const { employeeID, employeeName, documentName } = req.body;
    const file = req.file;

    if (!file) {
        return res.status(400).send({ error: 'Please upload a PDF file' });
    }

    const filename = file.filename;

    const newTransaction = new Transaction({
        employeeId: employeeID,
        employeeName: employeeName,
        documentName: documentName,
        fileName: filename
    });

    // Print the values received
    console.log('Employee ID:', employeeID);
    console.log('Employee Name:', employeeName);
    console.log('Document Name:', documentName);
    console.log('Uploaded File Name:', filename);

    try {
        await newTransaction.save();
        res.status(200).json({ message: 'Record saved successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Error saving transaction' });
    }
    send_file_for_loading(filename);

});

// Get list of employee data from DB
app.get('/list_employees', async (req, res) => {
    try {
        // Fetch all documents from the Transaction collection
        const transactions = await Transaction.find({});

        // Check if there are any documents
        if (!transactions.length) {
            return res.status(404).json({ message: 'No employees found' });
        }

        // Extract required fields
        const employeeData = transactions.map(doc => {
            return {
                employeeID: doc.employeeId || 'N/A',
                employeeName: doc.employeeName || 'N/A',
                documentName: doc.documentName || 'N/A',
                fileName: doc.fileName || 'N/A'
            };
        });

        // Send the extracted data as JSON
        res.json(employeeData);
    } catch (error) {
        console.error('Error fetching employees:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});


app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
