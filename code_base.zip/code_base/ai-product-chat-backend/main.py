
from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import shutil
from pydantic import BaseModel
from models import Response
import openai
import fitz  # PyMuPDF
from sentence_transformers import SentenceTransformer
from langchain.text_splitter import RecursiveCharacterTextSplitter
import pinecone
from pinecone import Pinecone, ServerlessSpec
import os
from dotenv import load_dotenv
from langchain.chat_models import ChatOpenAI
from langchain.chains import ConversationChain
from langchain.chains.conversation.memory import ConversationBufferWindowMemory
from langchain.prompts import (
    SystemMessagePromptTemplate,
    HumanMessagePromptTemplate,
    ChatPromptTemplate,
    MessagesPlaceholder
)

load_dotenv()

app = FastAPI()

origins = [
    "http://localhost",
    "http://localhost:3000",
    "http://localhost:4000",
]

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

model = SentenceTransformer('all-MiniLM-L6-v2')
openai_api_key = os.environ.get("OPENAI_API_KEY")
pinecone_api_key = os.environ.get("PINECONE_API_KEY")
pinecone_env = os.environ.get("PINECONE_ENV")
pinecone_index = os.environ.get("PINECONE_INDEX")

##pinecone.init(api_key=pinecone_api_key)
pc = Pinecone(api_key=pinecone_api_key)
index = pc.Index(pinecone_index)

def find_match(input):
    input_em = model.encode(input).tolist()
    ##name_space = "047675754567"
    result = index.query(vector=input_em, top_k=2, includeMetadata=True)
    return result['matches'][0]['metadata']['text'] + "\n" + result['matches'][1]['metadata']['text']

def get_chat_response(question):
    openai_api_key = os.environ.get("OPENAI_API_KEY")
    llm = ChatOpenAI(model_name="gpt-3.5-turbo", openai_api_key=openai_api_key)
    buffer_memory = ConversationBufferWindowMemory(k=3, return_messages=True)

    system_msg_template = SystemMessagePromptTemplate.from_template(
        template="""Answer the question as much as possible using the provided context'""")

    human_msg_template = HumanMessagePromptTemplate.from_template(template="{input}")

    prompt_template = ChatPromptTemplate.from_messages(
        [system_msg_template, MessagesPlaceholder(variable_name="history"), human_msg_template])

    conversation = ConversationChain(memory=buffer_memory, prompt=prompt_template, llm=llm, verbose=True)

    context = find_match(question)
    response = conversation.predict(input=f"Context:\n {context} \n\n Query:\n{question}")
    return response

## Function to load from folder to vector
def single_load(file_path):
    print(f"File path: {file_path}")


def locate_and_load(file_name):
    # Define the folder path
    folder_path = 'load_to_vector'

    # Construct the full file path
    file_path = os.path.join(folder_path, file_name)

    # Check if the file exists
    if os.path.exists(file_path):
        single_load(file_path)
    else:
        print(f"File '{file_name}' not found in folder '{folder_path}'")

    # Open the PDF file
    doc = fitz.open(file_path)

    # Read the entire text of the PDF
    text = ""
    for page in doc:
        text += page.get_text()

    # Split the text into smaller chunks
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=200,
        chunk_overlap=20,
        length_function=len
    )
    chunks = splitter.split_text(text)

    # Create embeddings for each chunk
    embeddings = model.encode(chunks)

    # Prepare data for Pinecone
    vectors = [
        {"id": f"chunk-{i}", "values": embedding, "metadata": {"text": chunk}}
        for i, (chunk, embedding) in enumerate(zip(chunks, embeddings))
    ]

    # Upsert vectors into Pinecone
    index.upsert(vectors)

    print(f"Loaded {len(vectors)} vectors into Pinecone index '{pinecone_index}'")


class ChatInput(BaseModel):
    message: str
@app.get('/')
def get_root():
    locate_and_load('SwethaResume.pdf')
    return "Endpoint - Get root"


@app.head('/')
def head_root():
    return "Head - get root"


@app.post('/bot_response/')
def get_bot_response(body: ChatInput):
    try:
        response = get_chat_response(body.message)
        return Response(200, "Success", response)

    except Exception as e:
        print("Exception,", e)
        return Response(500, "Failed")


@app.post("/loadvectordb")
async def loadvectordb(employee_id: str = Form(...), file: UploadFile = File(...)):
    upload_folder = "load_to_vector"
    os.makedirs(upload_folder, exist_ok=True)

    file_location = os.path.join(upload_folder, file.filename)

    try:
        # Save the uploaded file
        with open(file_location, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # Call the locate_and_load function
        if locate_and_load(file.filename):
            return JSONResponse(status_code=200, content={"message": "File successfully processed and loaded."})
        else:
            raise HTTPException(status_code=500, detail="File processing failed.")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))